<?php
    // $servername = "localhost";
    // $username = "root";
    // $password = "Honeydee";

    // $db_name = "petwatch";
    // $conn = mysqli_connect($servername, $username, $password, $db_name, "");

    // if ($conn->connect_error)
    //     die("Connection failed".$conn->connect_error);

    // echo "Success!";
// -----------------------------------------------------

    //online connection
    //$con=mysqli_connect('localhost','id19163526_gepampi','Honeydee@123','id19163526_login') or die ('no connection');

    //localhost connection
    $con=mysqli_connect('localhost', 'root','','petwatch') or die ('No connection');
    

?>
const loginI = document.querySelector("#loginEmail")
const passwordI = document.querySelector("#loginPassword")

let login = ""
let pass = ""


loginI.addEventListener("change",(e)=>{
    console.log(e.target.value);
})

